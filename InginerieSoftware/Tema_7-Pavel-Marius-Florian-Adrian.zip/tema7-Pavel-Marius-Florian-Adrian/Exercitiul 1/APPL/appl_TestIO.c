/* *****************************************************************************
   * Test stand LOCO - Testare masnsa tranctiune inainte/inapoi, frana, claxon
   * - 72 iesiri digitale (LED-uri, relee)
   *****************************************************************************
   * Nume Fisier:		appl_TestIO.c
   * Resurse:    		Nu
   * Processor:       	XMC4800F144
   * Compilator:      	DAVE™ v4 Product
   * Data:         		16.03.2026
   *
	Testare stand mansa tractiune inainte/inapoi, franare si claxon 
 *   - Cheie activa => locomotiva READY
 *   - Directie inainte/inapoi
 *   - Tractiune activa doar cand READY si exista directie valida
 *   - Frana forteaza dezactivarea tractiunii
 *   - Goarne activa pentru o perioada fixa la fiecare comanda ON, indiferent de durata comenzii
   ****************************************************************************	*/

	/* Standard de codare utilizat:
 	* Barr Group Embedded C Coding Standard
 	* https://barrgroup.com/embedded-systems/books/embedded-c-coding-standard
	*/

#include "appl_TestIO.h"
#include "DAVE.h"

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                   LOCAL DEFINES
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	*/
typedef enum
{
	LOCO_STATE_INIT = 0U,
	LOCO_STATE_STANDBY,
	LOCO_STATE_READY
} LOCO_STATE_E;

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    LOCAL VARIABLEs
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	*/
static LOCO_STATE_E m_LocoState = LOCO_STATE_INIT;
static BYTE m_HornPrev = STD_OFF;
static DWORD m_HornOffTime = 0U;

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                   LOCAL FUNCTION PROTOTYPEs
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	*/
static void Loco_ResetAllOutputs(void);
static void Loco_SetOutput(WORD wOutNb, BYTE bState);
static void Loco_WriteVersionToDisplay(void);
static BYTE Loco_ReadInput(WORD wInNb);
static void Loco_UpdateHorn(DWORD dwNowMs, BYTE bHornRequest);
static void Loco_UpdateDirection(BYTE bForwardCmd, BYTE bReverseCmd, BYTE *pbDirectionValid);

/* ****************************************************************************
   ------------------------  FUNCTIONs and PROCEDUREs  ------------------------
   ****************************************************************************	*/

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Function:   		Loco_ResetAllOutputs(void)
 * Input:   		No
 * Output:   		No
 * Description:   	Reseteaza toate cele 72 de iesiri la OFF
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
static void Loco_ResetAllOutputs(void)
{
WORD i;
	for(i = 1U; i <= LOCO_NR_IESIRI; i++)
	{
		Rte_Write_dioDigOutXyCANcmd(STD_OFF, i);
	}
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Function:   		Loco_SetOutput(WORD wOutNb, BYTE bState)
 * Input:   		wOutNb  - numarul iesirii (1..72)
 *                  bState  - STD_ON / STD_OFF
 * Output:   		No
 * Description:   	Seteaza starea unei iesiri digitale
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
static void Loco_SetOutput(WORD wOutNb, BYTE bState)
{
	if((wOutNb >= 1U) && (wOutNb <= LOCO_NR_IESIRI))
	{
		Rte_Write_dioDigOutXyCANcmd(bState, wOutNb);
	}
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Function:   		Loco_WriteVersionToDisplay(void)
 * Input:   		No
 * Output:   		No
 * Description:   	Scrie versiunea demo in campurile de versiune display
 *                  DATA16 = LOCO_VERSION_DATA16
 *                  applRTCpState[0] = LOCO_VERSION_RTC << 8 | 0x08
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
static void Loco_WriteVersionToDisplay(void)
{
WORD wTmpData;

	Rte_Write_applLOCOmainData(LOCO_VERSION_DATA16, 16U);

	wTmpData = ((WORD)LOCO_VERSION_RTC);
	wTmpData <<= 8;
	wTmpData |= (WORD)0x08;
	Rte_Write_applRTCpState(wTmpData, 0);
}

static BYTE Loco_ReadInput(WORD wInNb)
{
BYTE bState = STD_OFF;
	if((wInNb >= 1U) && (wInNb <= LOCO_NR_INTRARI))
	{
		Rte_Read_applInDigXstate(bState, wInNb);
	}
	return bState;
}

static void Loco_UpdateHorn(DWORD dwNowMs, BYTE bHornRequest)
{
	if((STD_ON == bHornRequest) && (STD_OFF == m_HornPrev))
	{
		m_HornOffTime = dwNowMs + LOCO_HORN_PULSE_MS;
		Loco_SetOutput(LOCO_OUT_HORN, STD_ON);
	}

	if((STD_ON == m_HornPrev) && (STD_OFF == bHornRequest) && (dwNowMs >= m_HornOffTime))
	{
		Loco_SetOutput(LOCO_OUT_HORN, STD_OFF);
	}

	if((STD_OFF == bHornRequest) && (dwNowMs >= m_HornOffTime))
	{
		Loco_SetOutput(LOCO_OUT_HORN, STD_OFF);
	}

	m_HornPrev = bHornRequest;
}

static void Loco_UpdateDirection(BYTE bForwardCmd, BYTE bReverseCmd, BYTE *pbDirectionValid)
{
	if((STD_ON == bForwardCmd) && (STD_OFF == bReverseCmd))
	{
		*pbDirectionValid = STD_ON;
		Loco_SetOutput(LOCO_OUT_FORWARD, STD_ON);
		Loco_SetOutput(LOCO_OUT_REVERSE, STD_OFF);
	}
	else if((STD_OFF == bForwardCmd) && (STD_ON == bReverseCmd))
	{
		*pbDirectionValid = STD_ON;
		Loco_SetOutput(LOCO_OUT_FORWARD, STD_OFF);
		Loco_SetOutput(LOCO_OUT_REVERSE, STD_ON);
	}
	else
	{
		*pbDirectionValid = STD_OFF;
		Loco_SetOutput(LOCO_OUT_FORWARD, STD_OFF);
		Loco_SetOutput(LOCO_OUT_REVERSE, STD_OFF);
	}
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Function:   		RTE_TestIOUpdate(void)
 * Input:   		No
 * Output:   		No
 * Description:   	Masina de stare principala pentru testarea intrarilor/iesirilor.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
void RTE_TestIOUpdate(void)
{
DWORD	dwTmpRTC_uS = STD_CTR_ZERO;		/* timpul curent [mS]				*/
BYTE	bMasterKey = STD_OFF;
BYTE	bForwardCmd = STD_OFF;
BYTE	bReverseCmd = STD_OFF;
BYTE	bTractionCmd = STD_OFF;
BYTE	bBrakeCmd = STD_OFF;
BYTE	bHornCmd = STD_OFF;
BYTE	bDirectionValid = STD_OFF;
BYTE	bTractionOut = STD_OFF;

	Rte_Read_RTC_mS_value(dwTmpRTC_uS);
	Loco_WriteVersionToDisplay();

	bMasterKey = Loco_ReadInput(LOCO_IN_MASTER_KEY);
	bForwardCmd = Loco_ReadInput(LOCO_IN_DIR_FORWARD);
	bReverseCmd = Loco_ReadInput(LOCO_IN_DIR_REVERSE);
	bTractionCmd = Loco_ReadInput(LOCO_IN_TRACTION);
	bBrakeCmd = Loco_ReadInput(LOCO_IN_BRAKE);
	bHornCmd = Loco_ReadInput(LOCO_IN_HORN);

	Loco_UpdateDirection(bForwardCmd, bReverseCmd, &bDirectionValid);

	switch(m_LocoState)
	{
	case LOCO_STATE_INIT:
		Loco_ResetAllOutputs();
		m_LocoState = LOCO_STATE_STANDBY;
		break;

	case LOCO_STATE_STANDBY:
		if(STD_ON == bMasterKey)
		{
			m_LocoState = LOCO_STATE_READY;
		}
		Loco_SetOutput(LOCO_OUT_READY, STD_OFF);
		Loco_SetOutput(LOCO_OUT_TRACTION, STD_OFF);
		Loco_SetOutput(LOCO_OUT_BRAKE, STD_OFF);
		break;

	case LOCO_STATE_READY:
		if(STD_OFF == bMasterKey)
		{
			m_LocoState = LOCO_STATE_STANDBY;
		}
		Loco_SetOutput(LOCO_OUT_READY, STD_ON);
		if((STD_ON == bDirectionValid) &&
		   (STD_ON == bTractionCmd) &&
		   (STD_OFF == bBrakeCmd))
		{
			bTractionOut = STD_ON;
		}
		Loco_SetOutput(LOCO_OUT_BRAKE, bBrakeCmd);
		Loco_SetOutput(LOCO_OUT_TRACTION, bTractionOut);
		break;

	default:
		m_LocoState = LOCO_STATE_INIT;
		break;
	}

	Loco_UpdateHorn(dwTmpRTC_uS, bHornCmd);

}/* RTE_TestIOUpdate */
