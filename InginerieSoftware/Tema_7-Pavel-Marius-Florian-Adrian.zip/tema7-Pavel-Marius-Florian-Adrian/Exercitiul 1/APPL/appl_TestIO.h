/* *****************************************************************************
   * Functii si proceduri pentru demo pupitru locomotiva
   *****************************************************************************
   * Nume Fisier:		appl_TestIO.h
   * Resurse:    		Nu
   * Processor:       	XMC4800F144
   * Compilator:      	DAVE™ v4 Product
   * Data:         		16.03.2026
   ****************************************************************************	*/

   	/* Standard de codare utilizat:
 	* Barr Group Embedded C Coding Standard
 	* https://barrgroup.com/embedded-systems/books/embedded-c-coding-standard
	*/

#ifndef APPL_APPL_TESTIO_H_
	#define APPL_APPL_TESTIO_H_

	#include "GenericTypeDefs.h"
	#include "Def_Var.h"
	#include "RTE_APPLvarState.h"

	#define LOCO_NR_INTRARI			120U
	#define LOCO_NR_IESIRI			 72U
	#define LOCO_HORN_PULSE_MS		300U
	#define LOCO_VERSION_DATA16		0x0C01U
	#define LOCO_VERSION_RTC		0x4CU	/* 'L' */

	#define LOCO_IN_MASTER_KEY		1U
	#define LOCO_IN_DIR_FORWARD		2U
	#define LOCO_IN_DIR_REVERSE		3U
	#define LOCO_IN_TRACTION		4U
	#define LOCO_IN_BRAKE			5U
	#define LOCO_IN_HORN			6U

	#define LOCO_OUT_READY			1U
	#define LOCO_OUT_FORWARD		2U
	#define LOCO_OUT_REVERSE		3U
	#define LOCO_OUT_TRACTION		4U
	#define LOCO_OUT_BRAKE			5U
	#define LOCO_OUT_HORN			6U

	extern void RTE_TestIOUpdate(void);		
#endif /* APPL_APPL_TESTIO_H_ */
