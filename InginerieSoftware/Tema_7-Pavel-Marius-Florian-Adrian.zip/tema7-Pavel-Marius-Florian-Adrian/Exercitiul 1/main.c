/* *****************************************************************************
   * Test stand LOCO - Testare masnsa tranctiune inainte/inapoi, frana, claxon
   *****************************************************************************
   * Nume Fisier:		main.c
   * Resurse:    		Nu
   * Processor:       	XMC4800F144
   * Compilator:      	DAVE™ v4 Product
   * Data:         		16.03.2026
   ****************************************************************************	*/

	/* Standard de codare utilizat:
 	* Barr Group Embedded C Coding Standard
 	* https://barrgroup.com/embedded-systems/books/embedded-c-coding-standard
	*/
	
#include "DAVE.h"
#include <xmc_ccu4.h>

#include "GenericTypeDefs.h"
#include "Def_Var.h"
#include "DefVar_init.h"
#include "RTE_APPLvarState.h"

#include "appl_DIO.h"
#include "appl_CANdata.h"
#include "appl_TestIO.h"

#define TIMER_500MS 500000*100U
#define TIMER_100MS 100000*100U

volatile uint32_t timetick_count = 0;
volatile uint16_t wTmpCanPct = 0;

/**
 * @brief main() - Application entry point
 */
int main(void)
{
DWORD	dTmpRTC_uS = STD_CTR_ZERO;
DAVE_STATUS_t status;

	RTE_Initialize();   			/* Software variables initialization 	*/
	RTE_CANsoftVarInitialize();		/* CAN soft variables initialize		*/
	status = DAVE_Init();           /* Initialization of DAVE APPs  		*/

	if(status != DAVE_STATUS_SUCCESS)
	{
		XMC_DEBUG("DAVE APPs initialization failed\n");
		while(1U)
		{
		}
	}

	/* Asteapta initializarea hardware (2.5s) */
	Rte_Read_RTC_mS_value(dTmpRTC_uS);
	while(dTmpRTC_uS < STD_Hwinit)
	{
		Rte_Read_RTC_mS_value(dTmpRTC_uS);
		RTE_DIO_Update();			/* Update all digital state         	*/
		RTE_TratComCAN();			/* Treats CAN communication 			*/
	}

	/* Bucla principala - logica demo locomotiva */
	while(1U)
	{
		RTE_DIO_Update();			/* Update all digital state         	*/
		RTE_TratComCAN();			/* Treats CAN communication 			*/
		RTE_TestIOUpdate();			/* Executie logica pupitru locomotiva	*/
	}
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Function name: 			Timer_IRQHandler( void )
 * Inputs:					No
 * Outputs:					No
 * Description:				Treats the interruption of TMR (1 mS)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	*/
void Timer_IRQHandler(void)
{
DWORD	dTmpRTC_uS = STD_CTR_ZERO;
WORD	wTmpRTC_InDigUpdate = STD_OFF;
WORD	wTmpRTC_OutDigUpdate = STD_OFF;
WORD	wTmpRTC_WatchdogCnt = STD_OFF;
WORD	wTmpRTC_Toggle500mS = STD_OFF;
BYTE    bTmpToggle500mS = STD_OFF;

	TIMER_ClearEvent(&TIMER_0);

	Rte_Read_RTC_mS_value(dTmpRTC_uS);
	Rte_Read_rtc_InDigUpdate(wTmpRTC_InDigUpdate);
	Rte_Read_rtc_OutDigUpdate(wTmpRTC_OutDigUpdate);
	Rte_Read_rtc_WatchdogCnt(wTmpRTC_WatchdogCnt);
	Rte_Read_rtc_Toggle500mS(wTmpRTC_Toggle500mS);
	Rte_Read_applToggle500mS(bTmpToggle500mS);

	dTmpRTC_uS++;

	if(STD_CTR_ZERO < wTmpRTC_InDigUpdate){ wTmpRTC_InDigUpdate--;}
	else {}
	if(STD_CTR_ZERO < wTmpRTC_OutDigUpdate){ wTmpRTC_OutDigUpdate--;}
	else {}

	if(STD_CTR_ZERO < wTmpRTC_WatchdogCnt){ wTmpRTC_WatchdogCnt--;}
	else {
		wTmpRTC_WatchdogCnt = STD_Watchdog;
	}

	if(STD_CTR_ZERO < wTmpRTC_Toggle500mS){ wTmpRTC_Toggle500mS--;}
	else {
		wTmpRTC_Toggle500mS = STD_Toggle500mS;
		bTmpToggle500mS = (STD_OFF == bTmpToggle500mS);
		DIGITAL_IO_ToggleOutput(&LED_WDG);
	}

	Rte_Write_RTC_mS_value(dTmpRTC_uS);
	Rte_Write_rtc_InDigUpdate(wTmpRTC_InDigUpdate);
	Rte_Write_rtc_OutDigUpdate(wTmpRTC_OutDigUpdate);
	Rte_Write_rtc_WatchdogCnt(wTmpRTC_WatchdogCnt);
	Rte_Write_rtc_Toggle500mS(wTmpRTC_Toggle500mS);
	Rte_Write_applToggle500mS(bTmpToggle500mS);

	TIMER_Start(&TIMER_0);

}/* Timer_IRQHandler */
