#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#define MAX_THREADS 16

char letters[] = "abcdefghijklmnopqrstuvwxyz";
char digits[] = "0123456789";

int found = 0;
int NUM_THREADS;
char name_rar[100];

CRITICAL_SECTION lock;

void save_password(const char* password)
{
    FILE* f = fopen("password_found.txt", "w");
    if (f)
    {
        fprintf(f, "Password found: %s\n", password);
        fclose(f);
    }
}

/* verificare fisier */
int file_exists(const char* filename)
{
    FILE* f = fopen(filename, "r");
    if (f)
    {
        fclose(f);
        return 1;
    }
    return 0;
}

DWORD WINAPI brute_force(LPVOID arg)
{
    int thread_id = *(int*)arg;
    char password[20];
    char command[256];

    for (int l1 = thread_id; l1 < 26; l1 += NUM_THREADS)
    {
        for (int l2 = 0; l2 < 26; l2++)
        {
            for (int l3 = 0; l3 < 26; l3++)
            {
                for (int l4 = 0; l4 < 26; l4++)
                {
                    for (int d1 = 0; d1 < 10; d1++)
                    {
                        for (int d2 = 0; d2 < 10; d2++)
                        {
                            if (found) return 0;

                            snprintf(password, sizeof(password),
                                "%c%c%c%c%c%czero",
                                letters[l1], letters[l2], letters[l3], letters[l4],
                                digits[d1], digits[d2]);

                            snprintf(command, sizeof(command),
                                "unrar x -p%s %s > nul 2>&1",
                                password, name_rar);

                            if (system(command) == 0)
                            {
                                EnterCriticalSection(&lock);

                                if (!found)
                                {
                                    printf("PASSWORD FOUND: %s\n", password);
                                    save_password(password);
                                    found = 1;
                                }

                                LeaveCriticalSection(&lock);
                                return 0;
                            }
                        }
                    }
                }
            }
        }
    }

    return 0;
}

int main()
{
    printf("Threads (max %d): ", MAX_THREADS);
    scanf_s("%d", &NUM_THREADS);

    if (NUM_THREADS > MAX_THREADS)
        NUM_THREADS = MAX_THREADS;

    printf("RAR file: ");
    scanf_s("%s", name_rar);

    if (!file_exists(name_rar))
    {
        printf("File not found!\n");
        return 1;
    }

    InitializeCriticalSection(&lock);

    HANDLE threads[MAX_THREADS];
    int ids[MAX_THREADS];

    for (int i = 0; i < NUM_THREADS; i++)
    {
        ids[i] = i;
        threads[i] = CreateThread(NULL, 0, brute_force, &ids[i], 0, NULL);
    }

    WaitForMultipleObjects(NUM_THREADS, threads, TRUE, INFINITE);

    DeleteCriticalSection(&lock);

    return 0;
}